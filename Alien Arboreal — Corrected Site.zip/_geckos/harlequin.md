---
name: Harlequin
status: available
featured: true
sex: Female
morph: Harlequin, red base
hatch_date: 2025-03-14
weight: "9.2 g (Aug 2026)"
price: "$350 CAD"
record_id: AA-2025-014
summary: "Bold red harlequin patterning with strong pinstriping. Steady eater, calm temperament."
---

Harlequin hatched from a spring 2025 clutch and has consistently held strong contrast between her base color and pattern through each shed. She's been on a stable feeding schedule since hatching and has never had a missed shed.

Full sire/dam pedigree will be linked here once the animal-record system is live.
