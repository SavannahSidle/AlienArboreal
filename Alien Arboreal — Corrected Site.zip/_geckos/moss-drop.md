---
name: Moss Drop
status: reserved
featured: false
sex: Male
morph: Dark olive dalmatian
hatch_date: 2024-11-02
weight: "11.8 g (Aug 2026)"
record_id: AA-2024-031
summary: "Heavy dalmatian spotting over an olive-moss base. Reserved as of August 2026."
---

Moss Drop is reserved pending pickup. Listed here for record continuity — contact for waitlist availability on similar future clutches.
