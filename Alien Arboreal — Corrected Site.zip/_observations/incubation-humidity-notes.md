---
title: "Incubation Humidity: Three Substrates Compared"
date: 2026-06-02
type: "Husbandry Note"
subject: "Incubation"
summary: "Informal side-by-side of perlite, vermiculite, and a coco-fiber mix across a single clutch season, tracking humidity drift and hatch outcomes."
---

This season I split a set of same-week clutches across three substrates to get a rough sense of humidity stability without buying a research-grade setup: perlite (1:1 water by weight), vermiculite (1:1), and a coco-fiber/perlite mix.

## Setup

Each container held a Hygrochron-style logger recording hourly. Ambient room conditions were shared across all three, so the substrate was the only deliberately varied factor.

## Observations

- The coco-fiber mix held the narrowest humidity band over the incubation window, with the least day-to-day drift.
- Perlite needed a light re-wetting roughly every 10–12 days; vermiculite held moisture noticeably longer but ran slightly wetter than targeted.
- No clear difference in hatch timing between substrates in this small sample — sample size is too small to draw a real conclusion here, just a note for next season's setup.

## Next steps

Planning a larger, more controlled run next season with matched clutch sizes per substrate and a logged temperature curve, not just humidity.
