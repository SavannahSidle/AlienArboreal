---
title: "Shed Skin Under Magnification: What's Actually There"
date: 2026-04-18
type: "Microscopy"
subject: "Ecdysis"
summary: "A closer look at retained shed tissue under a basic USB microscope, and what it does (and doesn't) tell you about hydration and shedding quality."
---

A cheap USB microscope is enough to see more structure in a shed than expected. This is a short, informal look at a few shed samples collected over one month, not a rigorous study.

## What was examined

Shed fragments from three animals were examined at roughly 50–200x magnification shortly after collection, focusing on the crest and dorsal scale regions where retained shed is most commonly reported.

## Notes

- Fully hydrated sheds came away in larger, more continuous sheets with visibly intact scale texture under magnification.
- Retained patches on toes and crest tips showed a duller, more fragmented surface — consistent with the usual advice to watch those areas closely during humid soaks.
- No sign of mite activity or unusual debris in any of the samples examined this round.

## Caveat

This is a hobbyist-level observation, not a diagnostic tool. It's a way to build a visual reference over time for what a good shed looks like versus one that needed help — nothing here should replace a vet exam for suspected retained shed or dysecdysis.
