---
title: About
eyebrow: Alien Arboreal
description: "Small-scale crested gecko breeding built around documentation: lineage, weights, feeding protocols, and clutch history."
permalink: /about/
---

Alien Arboreal is a small, Ottawa-based crested gecko (*Correlophus ciliatus*) operation focused on careful record-keeping and observation rather than volume production. Every animal that passes through here gets a documented lineage, a weight history, and a feeding protocol that's actually followed and refined over time.

## Why record-keeping first

Morphs and market trends come and go. What doesn't change is the value of good data: growth curves, clutch intervals, incubation variables, and behavioural notes that hold up over years, not just seasons. That's the foundation this site is built around, and it's why an Observations & Research section sits alongside the animal listings rather than off in a blog somewhere.

## What's here now

- **Available Geckos** — current crested gecko listings with status, morph notes, and lineage where relevant.
- **Observations & Research** — husbandry notes, informal experiments, microscopy observations, and literature summaries.

A full animal-record system — permanent IDs, sire/dam pedigree, pairing and clutch records, and permanent sold-animal history — is in development and will be layered in without disrupting the animals or notes already published here.

## Getting in touch

Alien Arboreal doesn't run an online store or checkout. All inquiries about available animals go through Instagram, Facebook, or email — see the [contact page]({{ '/contact/' | relative_url }}) for details.
