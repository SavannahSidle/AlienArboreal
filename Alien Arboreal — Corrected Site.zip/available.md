---
title: Available Geckos
eyebrow: Current Stock
description: "Crested geckos currently available, reserved, or recently placed. Inquiries via Instagram, Facebook, or email."
permalink: /available/
---

{% assign all_geckos = site.geckos | sort: "name" %}
{% assign available = all_geckos | where: "status", "available" %}
{% assign reserved = all_geckos | where: "status", "reserved" %}

{% if available.size > 0 %}
<div class="grid grid-3">
  {% for gecko in available %}
  <a href="{{ gecko.url | relative_url }}" class="card">
    {% if gecko.image %}
    <div class="card-image"><img src="{{ gecko.image | relative_url }}" alt="{{ gecko.name }}" loading="lazy"></div>
    {% else %}
    <div class="placeholder-art" role="img" aria-label="Photograph pending for {{ gecko.name }}">
      <svg viewBox="0 0 200 200" aria-hidden="true">
        <path d="M100 20 C70 55 55 90 55 120 C55 145 70 165 100 175 C130 165 145 145 145 120 C145 90 130 55 100 20 Z" fill="none" stroke="currentColor" stroke-width="1.2"/>
      </svg>
      <span>Photo pending</span>
    </div>
    {% endif %}
    <div class="card-body">
      <h2 class="card-title">{{ gecko.name }}</h2>
      <div class="card-meta">
        <span class="badge badge-available">Available</span>
        {% if gecko.morph %}<span>{{ gecko.morph }}</span>{% endif %}
      </div>
      {% if gecko.summary %}<p class="card-summary">{{ gecko.summary }}</p>{% endif %}
    </div>
  </a>
  {% endfor %}
</div>
{% else %}
<div class="empty-state">
  <p>No animals currently listed as available. New availability is posted on social media first.</p>
  <p>
    <a href="{{ site.instagram }}" rel="me noopener" target="_blank">Instagram</a> &middot;
    <a href="{{ site.facebook }}" rel="me noopener" target="_blank">Facebook</a> &middot;
    <a href="{{ '/contact/' | relative_url }}">Contact</a>
  </p>
</div>
{% endif %}

{% if reserved.size > 0 %}
<h2 class="mt-4">Reserved</h2>
<div class="grid grid-3">
  {% for gecko in reserved %}
  <a href="{{ gecko.url | relative_url }}" class="card">
    <div class="placeholder-art" role="img" aria-label="Photograph pending for {{ gecko.name }}">
      <svg viewBox="0 0 200 200" aria-hidden="true">
        <path d="M100 20 C70 55 55 90 55 120 C55 145 70 165 100 175 C130 165 145 145 145 120 C145 90 130 55 100 20 Z" fill="none" stroke="currentColor" stroke-width="1.2"/>
      </svg>
      <span>Photo pending</span>
    </div>
    <div class="card-body">
      <h2 class="card-title">{{ gecko.name }}</h2>
      <div class="card-meta"><span class="badge badge-reserved">Reserved</span></div>
    </div>
  </a>
  {% endfor %}
</div>
{% endif %}

<p class="specimen-note mt-4">Only crested geckos (<em>Correlophus ciliatus</em>) are listed individually at this time. Sold-animal history and full pedigree records are coming with the animal-record system.</p>
