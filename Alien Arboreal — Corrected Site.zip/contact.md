---
title: Contact
eyebrow: Get in Touch
description: "No online store or checkout — reach out directly about available geckos, pairings, or anything on the site."
permalink: /contact/
---

Alien Arboreal doesn't sell animals through the website — there's no cart, no checkout, and no online payment. Every inquiry is handled directly, one conversation at a time.

<div class="grid grid-3 mt-4">
  <div class="card card-pad">
    <h2 class="card-title">Instagram</h2>
    <p class="card-summary">Fastest way to ask about a specific animal or see the newest availability first.</p>
    <p><a href="{{ site.instagram }}" rel="me noopener" target="_blank">{{ site.instagram }}</a></p>
  </div>
  <div class="card card-pad">
    <h2 class="card-title">Facebook</h2>
    <p class="card-summary">Good for longer messages and for local Ottawa-area pickup coordination.</p>
    <p><a href="{{ site.facebook }}" rel="me noopener" target="_blank">{{ site.facebook }}</a></p>
  </div>
  <div class="card card-pad">
    <h2 class="card-title">Email</h2>
    <p class="card-summary">Best for detailed questions — husbandry history, pairing plans, or holding a reservation.</p>
    <p><a href="mailto:{{ site.email }}">{{ site.email }}</a></p>
  </div>
</div>

## Before you reach out

Mentioning the specific animal name (or the observation post that prompted your question) helps get a faster, more useful answer than a general inquiry.
