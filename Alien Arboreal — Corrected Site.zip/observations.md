---
title: Observations & Research
eyebrow: Field Notes
description: "Husbandry notes, informal experiments, microscopy observations, and literature summaries — the working logbook behind Alien Arboreal."
permalink: /observations/
---

{% assign entries = site.observations | sort: "date" | reverse %}

{% if entries.size > 0 %}
<div class="grid grid-3">
  {% for obs in entries %}
  <a href="{{ obs.url | relative_url }}" class="card">
    <div class="card-body">
      <h2 class="card-title">{{ obs.title }}</h2>
      <div class="card-meta">
        {% if obs.date %}<time datetime="{{ obs.date | date: '%Y-%m-%d' }}">{{ obs.date | date: "%B %-d, %Y" }}</time>{% endif %}
        {% if obs.type %}<span class="badge badge-outline">{{ obs.type }}</span>{% endif %}
      </div>
      {% if obs.summary %}<p class="card-summary">{{ obs.summary }}</p>{% endif %}
    </div>
  </a>
  {% endfor %}
</div>
{% else %}
<div class="empty-state">
  <p>Observation notes and research posts are in progress. Check back soon, or follow along on social media.</p>
</div>
{% endif %}

<p class="specimen-note mt-4">This section covers biological observations, husbandry notes, informal experiments, microscopy notes, and literature summaries — not sales listings.</p>
